package com.example.acer.androidtest;

import android.annotation.TargetApi;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DrawActivity extends AppCompatActivity implements View.OnClickListener {


    DatabaseHelper dbHelper;
    SQLiteDatabase thunderDB;

    Button b1, b2, btnsave, btnload, btnspace, btnline, btndelete, btnclear;
    EditText e1;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw);
        e1 = (EditText) findViewById(R.id.editText);
        b1 = (Button) findViewById(R.id.b1);
        b1.setOnClickListener(this);
        b2 = (Button) findViewById(R.id.b2);
        b2.setOnClickListener(this);
        btnsave = (Button) findViewById(R.id.save);
        btnsave.setOnClickListener(this);
        btnspace = (Button) findViewById(R.id.space);
        btnspace.setOnClickListener(this);
        btnline = (Button) findViewById(R.id.newline);
        btnline.setOnClickListener(this);
        btndelete = (Button) findViewById(R.id.delete);
        btndelete.setOnClickListener(this);
        btnclear = (Button) findViewById(R.id.clear);
        btnclear.setOnClickListener(this);
        btnload = (Button) findViewById(R.id.load);
        btnload.setOnClickListener(this);


        dbHelper = new DatabaseHelper(this);

        e1.requestFocus();
        e1.setShowSoftInputOnFocus(false);


    }

    @Override
    public void onClick(View view) {




        if (view.getId() == b1.getId()) {


            String temp = e1.getText().toString();

            temp = temp + "-";

            e1.setText(temp);
            e1.setSelection(temp.length());


        }

        if (view.getId() == b2.getId()) {


            String sam = e1.getText().toString();

            sam = sam + "|";

            e1.setText(sam);
            e1.setSelection(sam.length());
        }



        if(view.getId() == btnspace.getId()) {


            String sam = e1.getText().toString();

            sam = sam + " ";

            e1.setText(sam);
            e1.setSelection(e1.length());

        }


        if(view.getId() == btnline.getId()) {


            String sam = e1.getText().toString();

            sam = sam + "\n";

            e1.setText(sam);
            e1.setSelection(e1.length());


        }


        if(view.getId() == btndelete.getId()) {


            String sam = e1.getText().toString();

            sam = sam.substring(0, sam.length() - 1);

            e1.setText(sam);
            e1.setSelection(sam.length());


        }



        if (view.getId() == btnsave.getId()) {


            insertUser();


        }

        if(view.getId() == btnclear.getId()) {


            e1.getText().clear();


        }


        if(view.getId() == btnload.getId()) {



            displayData1();


        }

    }





    private void insertUser(){
        EditText edtdraw = (EditText) findViewById(R.id.editText);

        String draw = edtdraw.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Draw", draw);


        try{
            thunderDB = dbHelper.getWritableDatabase();
            thunderDB.insert("UserInfo",
                    null, cv);
            Log.v("Insert record","Successful");

        }catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        thunderDB.close();
    }

    private void displayData1() {


        try{
            thunderDB = dbHelper.getReadableDatabase();

            String columns[] = {"Draw"};

            Cursor cursor = thunderDB.query("UserInfo"
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                String draw = cursor.getString
                        (cursor.getColumnIndex("Draw"));



                String userInfo = draw;

                e1.setText(userInfo);


            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        thunderDB.close();

    }

}



    /*
    @Override
    public void onClick(View view) {


        if(view.getId() == b1.getId()) {


            String temp = e1.getText().toString();

            temp = temp + "|";

            e1.setText(temp);
            e1.setSelection(temp.length());

        }

        if(view.getId() == b2.getId()) {


            String temp = e1.getText().toString();

            temp = temp + "-";

            e1.setText(temp);
            e1.setSelection(temp.length());


        }

        if(view.getId() == btnspace.getId()) {


            String sam = e1.getText().toString();

            sam = sam + " ";

            e1.setText(sam);
            e1.setSelection(e1.length());

        }


        if(view.getId() == btnline.getId()) {


            String sam = e1.getText().toString();

            sam = sam + "\n";

            e1.setText(sam);
            e1.setSelection(e1.length());


        }


        if(view.getId() == btndelete.getId()) {


            String sam = e1.getText().toString();

            sam = sam.substring(0, sam.length() - 1);

            e1.setText(sam);
            e1.setSelection(sam.length());


        }


        if(view.getId() == btnclear.getId()) {


            e1.getText().clear();


        }


        if(view.getId() == btnsave.getId()) {


            insertUser();
            displayData();


        }


        if(view.getId() == btnload.getId()) {



            displayData1();


        }

    }




    private void insertUser(){
        EditText edtdraw = (EditText) findViewById(R.id.editText);

        String draw = edtdraw.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Draw", draw);


        try{
            thunderDB = dbHelper.getWritableDatabase();
            thunderDB.insert("UserInfo",
                    null, cv);
            Log.v("Insert record","Successful");

        }catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        thunderDB.close();
    }


    private void displayData(){

        try{
            thunderDB = dbHelper.getReadableDatabase();

            String columns[] = {"Draw"};

            Cursor cursor = thunderDB.query("UserInfo"
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                String draw = cursor.getString
                        (cursor.getColumnIndex("Draw"));



                String userInfo = draw;
                Toast.makeText(this,userInfo,
                        Toast.LENGTH_LONG).show();

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        thunderDB.close();

    }
    private void displayData1() {


        try{
            thunderDB = dbHelper.getReadableDatabase();

            String columns[] = {"Draw"};

            Cursor cursor = thunderDB.query("UserInfo"
                    ,columns,null,null,
                    null,null,null);

            while (cursor.moveToNext()){
                String draw = cursor.getString
                        (cursor.getColumnIndex("Draw"));



                String userInfo = draw;

                e1.setText(userInfo);


            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        thunderDB.close();

    }
*/




